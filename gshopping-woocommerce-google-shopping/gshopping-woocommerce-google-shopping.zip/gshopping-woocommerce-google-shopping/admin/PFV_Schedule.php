<?php
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

class PFVI_Schedule{

}