=== GShopping - WooCommerce Google Shopping ===
Contributors: villatheme, mrt3vn
Donate link: http://www.villatheme.com/donate
Tags:  WooCommerce Google Shopping, ecommerce, woocommerce, wordpress
Requires PHP: 7.0
Requires at least: 5.0
Tested up to: 5.8
Stable tag: 1.0.0
License: GPLv2 or later

== Description ==



== Changelog ==

/** 1.0.0 - 2021.07.23 **/
~ The first released.

== Upgrade Notice ==